import { UserService } from './../../shared/services/user/user.service';
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ThemesService } from 'src/app/shared/services/themes/themes.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {
  userDetails: any;
  constructor(public userService: UserService, private spinnerService: NgxSpinnerService, private themingService: ThemesService) { }

  ngOnInit() {
    this.spinnerService.show();
    this.getUserDetails();
  }
  /**
   * Gets user details. 
   */
  getUserDetails() {
    let userData = this.userService.getUserData();
    if (userData === undefined) {
      this.userService.getUserDetails().subscribe(details => {
        this.userDetails = details;
        this.spinnerService.hide();
      });
    }
    else {
      this.userDetails = this.userService.getUserData();
      this.spinnerService.hide();
    }
  }
  toggleDark() {
    this.themingService.toggleYemenTheme();
  }
  toggleLight() {
    this.themingService.togglePrimaryTheme();
  }
}
