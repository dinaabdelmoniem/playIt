import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentFawryComponent } from './payment-fawry.component';

describe('PaymentFawryComponent', () => {
  let component: PaymentFawryComponent;
  let fixture: ComponentFixture<PaymentFawryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentFawryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentFawryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
