import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-sms',
  templateUrl: './payment-sms.component.html',
  styleUrls: ['./payment-sms.component.scss']
})
export class PaymentSmsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
