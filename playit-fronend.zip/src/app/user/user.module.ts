import { UserRoutingModule } from './user-routing.module';
import { SubscribeComponent } from './subscribe/subscribe.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from './../shared/shared.module';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule } from '@angular/forms';

import { PaymentHomeComponent } from './pay/payment-home/payment-home.component';
import { PaymentFawryComponent } from './pay/payment-fawry/payment-fawry.component';
import { PaymentSmsComponent } from './pay/payment-sms/payment-sms.component';
import { PaymentVoucherComponent } from './pay/payment-voucher/payment-voucher.component';
import { FaqComponent } from './faq/faq.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    TranslateModule.forChild(),
    FormsModule,
    UserRoutingModule
  ],
  declarations: [
    SubscribeComponent,
    PaymentHomeComponent,
    PaymentFawryComponent,
    PaymentSmsComponent,
    PaymentVoucherComponent,
    FaqComponent,
    UserProfileComponent,
  ],
  exports: [SubscribeComponent]
})
export class UserModule { }
