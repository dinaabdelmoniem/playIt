import { CookieService } from 'ngx-cookie-service';
import { UserService } from './../user/user.service';
import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GuestService {

  constructor(private userService: UserService, private router: Router, private cookieService: CookieService) { }
  canActivate() {
    console.log(this.userService.getUserId());
    if (!this.userService.getUserId() && !this.cookieService.check('userId')) {
      this.router.navigate(['login']);
      return false;
    }
    else {
      return true;
    }
  }
}
