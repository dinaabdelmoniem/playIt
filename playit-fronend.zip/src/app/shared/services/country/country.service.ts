import { Injectable } from '@angular/core';
import { ConfigService } from '../config/config.service';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable} from 'rxjs';
import { Resolve } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CountryService implements Resolve<any> {
  public hostName: string;
  public countryName: string;
  public countryCode: string;
  public countryDetails: Subject<object> = new Subject<object>();
  constructor(
    private commonService: ConfigService,
    private http: HttpClient
  ) {
    this.hostName = this.commonService.getHostName();
  }
  resolve(){
    this.initiateCountry();
  }
  /**
   * Returns observable to subscriber
   */
  public getCountryDetails() {
    return this.countryDetails.asObservable();
  }
  /**
   * Subscribes to API that gets country details
   */
  initiateCountry() {
    return this.http.get(`${this.hostName}getcountry`);
  }

  /**
   * Adds country name and country code to stream of country details observable
   * @param countryName
   * @param countryCode
   */
  setCountryDetails(countryName, countryCode) {
    var countryInfo = { "countryName": countryName, "countryCode": countryCode };
    this.countryDetails.next(countryInfo);
    this.countryDetails.complete();
  }

  /* ------------------- start Em_Developer ------------------- */

  // Subscribes to API that gets country details
  initSubscribe(msisdn,password,name,email) {
    return this.http.get(`http://api.playit.mobi/api/v2/playit77/subscribe?msisdn=${msisdn}&password=${password}&name=${name}&email=${email}`);
  }

  fawrySubscribe(data) {
    return this.http.post(`http://api.playit.mobi/api/v2/payfawry`,data);
  }

  /* ------------------- end Em_Developer ------------------- */
}
