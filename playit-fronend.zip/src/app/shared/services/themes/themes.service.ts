import { Injectable } from '@angular/core';

export const primaryTheme = {
  'primary-color': '#0099cc',
  'background-color': '#FFF',
  'header-background': '#1f1f1f',
  'footer-background': '#FFF',
  'icons-color':'#2d2d2d',
  'text-color': '#2d2d2d',
  'tabs-color': '#0056a9',
  'side-menu-background': 'rgb(70, 73, 81)'
};
export const  yemenTheme = {
  'primary-color': '#FFCB05',
  'background-color': '#383b40',
  'header-background': '#FFCB05',
  'footer-background': '#FFCB05',
  'icons-color':'#FFF',
  'text-color': '#8a9ead',
  'tabs-color': '#FFCB05',
  'side-menu-background': 'rgb(70, 73, 81)'
};

@Injectable({
  providedIn: 'root'
})
export class ThemesService {

  constructor() { }


  togglePrimaryTheme() {
    this.setTheme(primaryTheme);
  }
  toggleYemenTheme() {
    this.setTheme(yemenTheme);
  }

  private setTheme(theme: {}) {
    Object.keys(theme).forEach(k => {
      document.documentElement.style.setProperty(`--${k}`, theme[k])
    }
    );
  }
}
