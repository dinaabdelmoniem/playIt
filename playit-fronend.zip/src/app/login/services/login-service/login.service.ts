import { UserService } from './../../../shared/services/user/user.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from '../../../shared/services/config/config.service';
import { Router } from '@angular/router';
 
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  hostName: string;
  constructor(private http: HttpClient, private configService: ConfigService,
    private userService: UserService, private router: Router) {
    this.hostName = this.configService.getHostName();
  }
  canActivate() {
    if (this.userService.getUserId()) {
      this.router.navigate(['/home/games/lobby']);
      return false;
    } else {
      return true;
    }
  }
  loginUser(userData) {
    return this.http.post(`${this.hostName}login`, userData);
  }
  checkUserExist(username) {
    return this.http.get(`${this.hostName}checkusername/${username}`);
  }
  sendPasswordSMS(username) {
    return this.http.get(`${this.hostName}sendpassword/${username}`);
  }

  logout () {
    //return this.http.get(`http://api.playit.mobi/api/v2/playit77/logout`); 
    //return this.http.get(`http://api.playit.mobi/api/v2/playit77/logout`); 
    return this.http.get(`${this.hostName}logout`); 
  }
}
