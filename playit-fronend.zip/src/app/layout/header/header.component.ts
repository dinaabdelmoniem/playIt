import { CountryService } from './../../shared/services/country/country.service';
import { Router, NavigationStart } from '@angular/router';
import { Component, OnInit, OnChanges, Output, EventEmitter, Input } from '@angular/core';
import { UserService } from '../../shared/services/user/user.service';
import { Location } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() headerView = '';
  @Output() public childEvent = new EventEmitter();
  oldLocation: string = '';
  interval: any;
  constructor(private translateService: TranslateService, private countryService: CountryService, private userService: UserService, private router: Router, private _location: Location) { 
   
  }

  isUserExist: boolean;
  isBackDisabled: boolean = true;
  noBack: boolean = true;
  showSearch: boolean = false;
  inputSearch: string;
  lang: string = 'en';
  successLogin: string;
  customM: boolean = true;
  countryCode: string;
  ngOnInit() {
    this.getCountry();
    this.checkBackEnabled();
    this.getUserStatus();
    this.customMenu();
  }
  /**
   * Subscribes to observable to get country details
   */
  getCountry() {
    this.countryService.getCountryDetails().subscribe(country => {
      this.countryCode = country['countryCode'];
    });
  }
  /**
   * Subscribes to router events and changed value of isBackDisabled to true on certain events
   */
  checkBackEnabled() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        if (event.url === '/home/games/lobby' || event.url === '/home/games/online' || event.url === '/home/games/android' || event.url === '/login' || event.url === '/subscribe') {
          this.isBackDisabled = false;
          this.noBack = true;
        }
        else {
          this.isBackDisabled = true;
          this.noBack = false;
        }
      }
    });
  }
  /**
   * Subscribes to get userStatus observable to check if user is logged in
   */
  getUserStatus() {
    this.userService.getUserStatus().subscribe(user => {
      this.isUserExist = user['isUserExist'];
    });
  }

  backClicked() {
    this._location.back();
  }

  checkOnChangeRoute() {
    if (this.showSearch == true) {
      this.interval = setInterval(() => {
        if (this.oldLocation !== this.router.url) {
          this.showSearch = false;
          clearInterval(this.interval);
        }
      }, 1000);
    }
  }

  searchShow() {
    if (this.showSearch == false) {
      this.showSearch = true;
      this.oldLocation = this.router.url;
      this.checkOnChangeRoute();
    } else if (this.showSearch == true) {
      this.showSearch = false;
    }
  }

  searchNow() {
    console.log(this.inputSearch);
    if (this.inputSearch.length > 0) {
      this.router.navigateByUrl('search/' + this.inputSearch);
      this.showSearch = false;
      this.inputSearch = '';
    }
  }

  searchClose() {
    this.showSearch = false;
    this.inputSearch = '';
  }

  /*
   ** custom menu in login & subscribe pages
  */
  customMenu() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        if (event.url == '/login' || event.url == '/subscribe') {
          this.customM = false;
        }
        else {
          this.customM = true;
        }
      }
    });
  }

}
