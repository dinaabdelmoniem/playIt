import { CountryService } from './../../shared/services/country/country.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  countryCode: string;
  constructor(private countryService: CountryService) { }

  ngOnInit() {
    this.getCountry();
  }
  /**
   * Subscribes to observable to get country details
   */
  getCountry() {
    this.countryService.getCountryDetails().subscribe(country => {
      this.countryCode = country['countryCode'];
    });
  }
}
