import { UserService } from './../../shared/services/user/user.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login/services/login-service/login.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  userDetails: any;
  user_id:any;
  constructor(
    private userService: UserService,
    private router:Router,
    private loginService:LoginService
  ) {}

  ngOnInit() {
    this.getUserDetails();
  }
  /**
   * Gets user details and sets it in local variable
   */
  getUserDetails() {
    this.userService.getUserDetails().subscribe(user => {
      this.userDetails = user;
      console.log("USER DETAILS", this.userDetails);
    });
  }

  /* 
  ** logout 
  ** no work :(
  */
  logout() {
    console.log('progress');
    this.loginService.logout().subscribe(next => {
      localStorage.clear();
      var newWindow = window.open();
      console.log('success', next);
      //newWindow.location.href = '/login';
    },error=>{
      console.log(error)
    });
  }

  /*  
  ** unsubscribe
  */
  unsubscribe(){
    this.user_id = this.userService.getUserId();
    console.log('user_id', this.user_id);
    this.userService.unsubscribe(this.user_id).subscribe(next=>{console.log(next)
    localStorage.clear();
    this.router.navigate(['/home']);
    },error=>{console.log(error)})
  }

}
