import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http: HttpClient) { }

  // search
  searchGames(searchQuery) {
    return this.http.post(`http://www.api.playit.mobi/api/v1/searchGames`, {'search_query': searchQuery});
  }
}
