import { CountryService } from './shared/services/country/country.service';
import { FaqComponent } from './user/faq/faq.component';
import { CategoryComponent } from './games/category/category.component';
import { PaymentVoucherComponent } from './user/pay/payment-voucher/payment-voucher.component';
import { PaymentSmsComponent } from './user/pay/payment-sms/payment-sms.component';
import { PaymentFawryComponent } from './user/pay/payment-fawry/payment-fawry.component';
import { PaymentHomeComponent } from './user/pay/payment-home/payment-home.component';
import { SearchComponent } from './layout/search/search.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GameDetailsComponent } from './games/game-details/game-details.component';
import { SubscribeComponent } from './user/subscribe/subscribe.component';
import { PlayComponent } from './games/play/play.component';
import { GuestService } from './shared/services/guest/guest.service';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home/games/lobby',
    pathMatch: 'full',
    resolve: {
      country: CountryService
    }
  },
  {
    path: 'login',
    loadChildren: './login/login.module#LoginModule'
  },
  {
    path: 'home',
    loadChildren: './home/home.module#HomeModule'
  },
  {
    path: 'user',
    loadChildren: './user/user.module#UserModule'
  },
  {
    path: 'game/:gametype/:gameid',
    component: GameDetailsComponent,
    canActivate: [GuestService]
  },
  {
    path: 'play/:gametype/:gameid',
    component: PlayComponent
  },
  {
    path: 'pay',
    component: PaymentHomeComponent
  },
  {
    path: 'faq',
    component: FaqComponent
  },
  {
    path: 'pay/fawry',
    component: PaymentFawryComponent
  },
  {
    path: 'pay/sms',
    component: PaymentSmsComponent
  },
  {
    path: 'pay/voucher',
    component: PaymentVoucherComponent
  },
  {
    path: 'subscribe',
    component: SubscribeComponent
  },
  {
    path: 'search/:inputSearch',
    component: SearchComponent
  },
  {
    path: 'category/:category_name',
    component: CategoryComponent,
    data: { gametype: 'all' }
  },
  {
    path: 'category/:type/:category_name',
    component: CategoryComponent
  },
  {
    path: 'androidcategory/:category_name',
    component: CategoryComponent,
    data: { gametype: 'android' }
  },
  {
    path: '**',
    redirectTo: 'home/games/lobby',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  declarations: []
})
export class AppRoutingModule { }
