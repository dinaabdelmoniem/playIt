import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GamesService } from '../services/games/games.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-list-games',
  templateUrl: './list-games.component.html',
  styleUrls: ['./list-games.component.scss']
})
export class ListGamesComponent implements OnInit {

  constructor(private router:Router, private activatedRoute: ActivatedRoute, private gamesService: GamesService, private spinnerService: NgxSpinnerService) { }
  gamesCategories: Array<object>;
  game_type:any = "";
  ngOnInit() {
    this.getGamesType();
  }
  /**
   * Determines type of game from data on routed to
   */
  getGamesType() {
    this.activatedRoute.data.subscribe(data => {
      this.game_type = data['gameType'];
      this.spinnerService.show();
      switch (data['gameType']) {
        case 'all':
          this.getAllGames();
          break;
        default:
          this.getAllGamesWithType(data['gameType']);
          break;
      }
    });
  }
  /**
   * Gets all games with type either android or online 
   * @param gameType 
   */
  getAllGamesWithType(gameType) {
    this.gamesService.getAllGamesWithType(gameType, 2).subscribe(games => {
      this.gamesCategories = games['game_list'];
      console.log(this.gamesCategories);
      console.log('games',games);
      this.spinnerService.hide();
    });
  }
  /**
   * Gets all games with all types
   */
  getAllGames() {
    this.gamesService.getAllGames(2).subscribe(
      games => {
        this.gamesCategories = games['game_list'];
        this.spinnerService.hide();
      }
    );
  }

  goCategory(cat_name) {
    console.log(cat_name);
    console.log(this.game_type);
    if(this.game_type == 'andriod'){
      console.log('inside android');
      this.router.navigateByUrl('/category/android/'+cat_name);
    }else if(this.game_type == 'easy'){
      console.log('outside android',this.game_type);
      this.router.navigateByUrl('/category/online/'+cat_name);
    }
    else if(this.game_type == 'all'){
      console.log('outside android',this.game_type);
      this.router.navigateByUrl('/category/lobby/'+cat_name);
    }
  }
}
