import { IframePipe } from './iframe.pipe';

describe('IframePipe', () => {
  it('create an instance', () => {
    const pipe = new IframePipe();
    expect(pipe).toBeTruthy();
  });
});
