import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'iframe'
})
export class IframePipe implements PipeTransform {

  constructor(private dom:DomSanitizer){};

  transform(value: any, args?: any): any {
    // value = value + '';
    return this.dom.bypassSecurityTrustResourceUrl(value);
  }

}
