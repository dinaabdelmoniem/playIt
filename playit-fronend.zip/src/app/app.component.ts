import { ThemesService } from './shared/services/themes/themes.service';
import { Component, OnInit, OnChanges} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CountryService } from './shared/services/country/country.service';
import { UserService } from './shared/services/user/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnChanges {
headerView = '';
navLink ='';
  constructor(
    private translateService: TranslateService,
    private countryService: CountryService,
    private userService: UserService,
    private themeService: ThemesService,
    private router : Router,
    private activatedRoute : ActivatedRoute
  ) {
   
this.navLink = window.location.href ;
if(this.navLink.includes("login")){
  this.headerView = "login";
}
else if (this.navLink.includes("subscribe")){
  this.headerView = "subscribe";
}
else{
  this.headerView = "sharedHeader";
}
}

  ngOnInit() {
    this.initiateProject();
  }
  ngOnChanges() {
  }
  /**
   ** Calls necessary methods to initiate project.
   */
  initiateProject() {
    this.getCountry().then((country) => {
      this.setTheme(country);
      this.setDefaultLanguage(country);
      this.userService.handleUser();
    })
  }
  setDefaultLanguage(country) {
    switch (country) {
    case 'YE':
      this.translateService.setDefaultLang('ar');
      break;
    case 'EG':
      this.translateService.setDefaultLang('ar');
      break;
    default:
      this.translateService.setDefaultLang('en');
      break;
    }
  }
  /**
   * Sets theme depending on country
   * @param country
   */
  setTheme(country) {
    switch (country) {
      case 'YE':
        this.themeService.toggleYemenTheme();
        break;
      default:
        this.themeService.togglePrimaryTheme();
        break;
    }
  }
  /**
   * Subscribes to API to get country
   */
  getCountry() {
    return new Promise((resolve, reject) => {
      this.countryService.initiateCountry().subscribe(country => {
        this.countryService.setCountryDetails(country['country_name'], country['country_code']);
        resolve(country['country_code']);
      });
    });
  }
}
